﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Procon2015_2
{
    class AGI_CalcFields
    {
        const int F_MAX_X = 34; /* 問題最大32 壁2 */
        const int F_MAX_Y = 34; /* ↑ */

        const int EMPUTY = 0;
        const int MY_FIELD = 1;
        const int WALL = 3;
        const int OBJECT = 5;
        const int NEIGHT1 = -11;
        const int NEIGHT2 = -13;

        const int SCORE_MAX = 5;    /* 3辺以上接地 */
        const int SCORE_MID = 2;    /* 2辺接地 */
        const int SCORE_MIN = 1;    /* 1辺接地 */
        const int NON_SCORE = 0;    /* 0辺接地 */

        int[] fields;

        public AGI_CalcFields()
        {
            fields = new int[F_MAX_X * F_MAX_Y];
            for(int i=0; i < fields.Length; i++)
            {
                fields[i] = 0;
            }
        }

        public AGI_CalcFields(AGI_Fields agiF)
        {
            fields = new int[F_MAX_X * F_MAX_Y];

            for(int i=0; i < fields.Length; i++)
            {
                fields[i] = agiF.GetAgiFieldsNum(i);
            }

            addNeighborInfo();
        }

        public AGI_CalcFields(string strFields)
        {
            fields = new int[F_MAX_X * F_MAX_Y];
            int counter = 0;
            bool preMinusFlg = false;
            bool preMinusFlg2 = false;

            if (strFields.Length >= fields.Length)
            {
                for(int i=0; i < strFields.Length; i++)
                {
                    string s = strFields.Substring(i, 1);   /* i番目から一文字取得 */


                    if (s == "0")
                    {
                        fields[counter] = EMPUTY;
                        counter++;
                    }
                    else if (s == "5")
                    {
                        fields[counter] = OBJECT;
                        counter++;
                    }
                    else if (s == "-")
                    {
                        preMinusFlg = true;
                    }
                    else if (s == "1")
                    {
                        if (preMinusFlg == false)
                        {
                            fields[counter] = MY_FIELD;
                            counter++;
                        }
                        else if (preMinusFlg2 == false)
                        {
                            preMinusFlg2 = true;
                        }
                        else if (preMinusFlg2 == true)
                        {
                            fields[counter] = NEIGHT1;
                            preMinusFlg = false;
                            preMinusFlg2 = false;
                            counter++;
                        }
                        else
                        {
                            ;
                        }
                    }
                    else if (s == "3")
                    {
                        if (preMinusFlg == false)
                        {
                            fields[counter] = WALL;
                            counter++;
                        }
                        else if ((preMinusFlg == true) && (preMinusFlg2 == true))
                        {
                            fields[counter] = NEIGHT2;
                            preMinusFlg = false;
                            preMinusFlg2 = false;
                            counter++;
                        }
                    }
                }
            }
        }

        private void addNeighborInfo()
        {
            /* STEP1:壁や障害物,自陣と接触するEMPUTYセルをNEIGHT1に */
            /* STEP2:NEIGHT1と接触するEMPUTYセルをNEIGHT2に */
            
            /* STEP1 */
            for(int i=0; i<fields.Length; i++)
            {
                if((fields[i] == MY_FIELD)|| (fields[i] == WALL) || (fields[i] == OBJECT))
                { 
                    /* 上 */
                    if(i - F_MAX_X >= 0)
                    {
                        if(fields[i - F_MAX_X] == EMPUTY)
                        {
                            fields[i - F_MAX_X] = NEIGHT1;
                        }
                    }
                    /* 下 */
                    if (i + F_MAX_X < fields.Length)
                    {
                        if (fields[i + F_MAX_X] == EMPUTY)
                        {
                            fields[i + F_MAX_X] = NEIGHT1;
                        }
                    }
                    /* 左 */
                    if( i - 1 >= 0)
                    {
                        if(fields[i - 1] == EMPUTY)
                        {
                            fields[i - 1] = NEIGHT1;
                        }
                    }
                    /* 右 */
                    if(i + 1 < fields.Length)
                    {
                        if(fields[i+1] == EMPUTY)
                        {
                            fields[i + 1] = NEIGHT1;
                        }
                    }
                }
            }

            /* STEP2 */
            for (int i = 0; i < fields.Length; i++)
            {
                if (fields[i] == NEIGHT1)
                {
                    /* 上 */
                    if (i - F_MAX_X >= 0)
                    {
                        if (fields[i - F_MAX_X] == EMPUTY)
                        {
                            fields[i - F_MAX_X] = NEIGHT2;
                        }
                    }
                    /* 下 */
                    if (i + F_MAX_X < fields.Length)
                    {
                        if (fields[i + F_MAX_X] == EMPUTY)
                        {
                            fields[i + F_MAX_X] = NEIGHT2;
                        }
                    }
                    /* 左 */
                    if (i - 1 >= 0)
                    {
                        if (fields[i - 1] == EMPUTY)
                        {
                            fields[i - 1] = NEIGHT2;
                        }
                    }
                    /* 右 */
                    if (i + 1 < fields.Length)
                    {
                        if (fields[i + 1] == EMPUTY)
                        {
                            fields[i + 1] = NEIGHT2;
                        }
                    }
                }
            }

        }

        public void PrintAgiCalcFields()
        {
            Console.WriteLine("");
            for (int i = 0; i < fields.Length; i++)
            {
                if ((i % F_MAX_X) == 0)
                {
                    Console.WriteLine("");
                }
                Console.Write("{0, 3},",fields[i]);
            }
        }

        public int GetAgiCalcFieldsSize()
        {
            return fields.Length;
        }

        public int GetAgiCalcFieldNum(int idx)
        {
            if(idx < fields.Length)
            {
                return fields[idx];

            }
            return -1;
        }

        public int GetAgiCalcScore()
        {
            int retScore = 0;

            for(int i=0; i < fields.Length; i++)
            {
                if(fields[i] == MY_FIELD)
                {
                    retScore++;
                }
            }
            return retScore;
        }

        /* 評価値に石のサイズが影響しない評価関数 */
        public float GetAgiCalcEval(AGI_CalcFields beforeAgiF)
        {
            float retEval = 0;
            int stoneCnt = 0;
            int closedCnt = 0;

            for (int i = 0; i < fields.Length; i++)
            {
                int cntEdge = 0;    /* スコア対象の辺の数をカウント */
                if (beforeAgiF.GetAgiCalcFieldNum(i) != MY_FIELD && fields[i] == MY_FIELD)    /* 前回から今回で自陣に変化した場合 */
                {
                    stoneCnt++;
                    /* 上 */
                    if (i - F_MAX_X >= 0)
                    {
                        /* エッジ接続チェック */
                        if (fields[i - F_MAX_X] == MY_FIELD)
                        {
                            cntEdge++;
                        }

                        /* 閉路チェック */
                        if (checkClosedCell(i - F_MAX_X) == false)
                        {
                            closedCnt++;
                        }

                    }
                    /* 下 */
                    if (i + F_MAX_X < fields.Length)
                    {
                        if (fields[i + F_MAX_X] == MY_FIELD)
                        {
                            cntEdge++;
                        }
                        if (checkClosedCell(i + F_MAX_X) == false)
                        {
                            closedCnt++;
                        }
                    }
                    /* 左 */
                    if (i - 1 >= 0)
                    {
                        if (fields[i - 1] == MY_FIELD)
                        {
                            cntEdge++;
                        }
                        if (checkClosedCell(i - 1) == false)
                        {
                            closedCnt++;
                        }
                    }
                    /* 右 */
                    if (i + 1 < fields.Length)
                    {
                        if (fields[i + 1] == MY_FIELD)
                        {
                            cntEdge++;
                        }
                        if (checkClosedCell(i + 1) == false)
                        {
                            closedCnt++;
                        }

                    }
                }

                if (cntEdge >= 3)
                {
                    retEval += SCORE_MAX;
                }else if(cntEdge == 2)
                {
                    retEval += SCORE_MID;
                }else if(cntEdge == 1)
                {
                    retEval += SCORE_MIN;
                }
                else
                {
                    retEval += NON_SCORE;
                }
            }

            if (closedCnt >= 2)
            {
                retEval = retEval / 5.0F;
            }
            else if (closedCnt >= 1)
            {
                retEval = retEval / 3.0F;
            }
            else
            {
                ;
            }


            return ((float)retEval/ (float)stoneCnt);
        }

        /* 評価値に石のサイズが影響する評価関数 */
        public float GetAgiCalcEvalSize(AGI_CalcFields beforeAgiF)
        {
            float retEval = 0.0F;
            int closedCnt = 0;

            for (int i = 0; i < fields.Length; i++)
            {
                int cntEdge = 0;    /* スコア対象の辺の数をカウント */
                if (beforeAgiF.GetAgiCalcFieldNum(i) != MY_FIELD && fields[i] == MY_FIELD)    /* 前回から今回で自陣に変化した場合 */
                {
                    /* 上 */
                    if (i - F_MAX_X >= 0)
                    {
                        /* エッジ接続チェック */
                        if (fields[i - F_MAX_X] == MY_FIELD)
                        {
                            cntEdge++;
                        }

                        /* 閉路チェック */
                        if (checkClosedCell(i - F_MAX_X) == false)
                        {
                            closedCnt++;
                        }

                    }
                    /* 下 */
                    if (i + F_MAX_X < fields.Length)
                    {
                        if (fields[i + F_MAX_X] == MY_FIELD)
                        {
                            cntEdge++;
                        }
                        if (checkClosedCell(i + F_MAX_X) == false)
                        {
                            closedCnt++;
                        }
                    }
                    /* 左 */
                    if (i - 1 >= 0)
                    {
                        if (fields[i - 1] == MY_FIELD)
                        {
                            cntEdge++;
                        }
                        if (checkClosedCell(i - 1) == false)
                        {
                            closedCnt++;
                        }
                    }
                    /* 右 */
                    if (i + 1 < fields.Length)
                    {
                        if (fields[i + 1] == MY_FIELD)
                        {
                            cntEdge++;
                        }
                        if (checkClosedCell(i + 1) == false)
                        {
                            closedCnt++;
                        }

                    }
                }

                if (cntEdge >= 3)
                {
                    retEval += SCORE_MAX;
                }
                else if (cntEdge == 2)
                {
                    retEval += SCORE_MID;
                }
                else if (cntEdge == 1)
                {
                    retEval += SCORE_MIN;
                }
                else
                {
                    retEval += NON_SCORE;
                }
            }

            if (closedCnt >= 2)
            {
                retEval = retEval / 3.0F;
            }
            else if (closedCnt >= 1)
            {
                retEval = retEval / 2.0F;
            }
            else
            {
                ;
            }


            return ((float)retEval);
        }

        /* 評価値に石のサイズが影響する評価関数 */
        public float GetAgiCalcEvalSizeKai(AGI_CalcFields beforeAgiF, int score)
        {
            float retEval = 0.0F;
            int closedCnt = 0;

            for (int i = 0; i < fields.Length; i++)
            {
                int cntEdge = 0;    /* スコア対象の辺の数をカウント */
                if (beforeAgiF.GetAgiCalcFieldNum(i) != MY_FIELD && fields[i] == MY_FIELD)    /* 前回から今回で自陣に変化した場合 */
                {
                    /* 上 */
                    if (i - F_MAX_X >= 0)
                    {
                        /* エッジ接続チェック */
                        if (fields[i - F_MAX_X] == MY_FIELD)
                        {
                            cntEdge++;
                        }

                        /* 閉路チェック */
                        if(checkClosedCell(i - F_MAX_X) == false)
                        {
                            closedCnt++;
                        }

                    }
                    /* 下 */
                    if (i + F_MAX_X < fields.Length)
                    {
                        if (fields[i + F_MAX_X] == MY_FIELD)
                        {
                            cntEdge++;
                        }
                        if (checkClosedCell(i + F_MAX_X) == false)
                        {
                            closedCnt++;
                        }
                    }
                    /* 左 */
                    if (i - 1 >= 0)
                    {
                        if (fields[i - 1] == MY_FIELD)
                        {
                            cntEdge++;
                        }
                        if (checkClosedCell(i - 1) == false)
                        {
                            closedCnt++;
                        }
                    }
                    /* 右 */
                    if (i + 1 < fields.Length)
                    {
                        if (fields[i + 1] == MY_FIELD)
                        {
                            cntEdge++;
                        }
                        if (checkClosedCell(i + 1) == false)
                        {
                            closedCnt++;
                        }

                    }
                }

                if (cntEdge >= 3)
                {
                    retEval += SCORE_MAX;
                }
                else if (cntEdge == 2)
                {
                    retEval += SCORE_MID;
                }
                else if (cntEdge == 1)
                {
                    retEval += SCORE_MIN;
                }
                else
                {
                    retEval += NON_SCORE;
                }
            }

            retEval = retEval * 0.8F + (float)score * 0.2F;

            if(closedCnt >= 2)
            {
                retEval = retEval / 5.0F;
            }else if(closedCnt >= 1)
            {
                retEval = retEval / 3.0F;
            }
            else
            {
                ;
            }

            return (retEval);
        }

        private bool checkClosedCell(int idx)
        {
            bool result = false;
            if ((fields[idx] == NEIGHT1)||(fields[idx]==NEIGHT2)||(fields[idx] == EMPUTY))
            {
                /* 上 */
                if (idx - F_MAX_X >= 0)
                {
                    if (fields[idx - F_MAX_X] == EMPUTY || fields[idx - F_MAX_X] == NEIGHT1 || fields[idx - F_MAX_X] == NEIGHT2)
                    {
                        result = true;
                    }
                }
                /* 下 */
                if (idx + F_MAX_X < fields.Length)
                {
                    if (fields[idx + F_MAX_X] == EMPUTY || fields[idx + F_MAX_X] == NEIGHT1 || fields[idx + F_MAX_X] == NEIGHT2)
                    {
                        result = true;
                    }
                }
                /* 左 */
                if (idx - 1 >= 0)
                {
                    if (fields[idx - 1] == EMPUTY || fields[idx - 1] == NEIGHT1 || fields[idx - 1] == NEIGHT2)
                    {
                        result = true;
                    }
                }

                /* 右 */
                if (idx + 1 < fields.Length)
                {
                    if (fields[idx + 1] == EMPUTY || fields[idx + 1] == NEIGHT1 || fields[idx + 1] == NEIGHT2)
                    {
                        result = true;
                    }
                }
            }
            else
            {
                result = true;
            }

            return result;

        }

        public void SetAgiCalcNum(int idx, int num)
        {
            if(idx < fields.Length)
            {
                fields[idx] = num;
            }
        }

        public void SetAgiCalcCopyFromA(AGI_CalcFields A)
        {
            for(int i=0; i < fields.Length; i++)
            {
                this.fields[i] = A.fields[i];
            }
        }

        public int GetMaxX()
        {
            return F_MAX_X;
        }

        public int GetMaxY()
        {
            return F_MAX_Y;
        }

         /* Searchクラスでの加算結果を元に戻す関数 */
        public void GetReturnCalcFld()
        {
            /* 各定数情報 
             * AGI_FIELDS 
             *     空：0
             *     自：1
             *     障：5
             *     近1:-11
             *     近2:-13
             *
             * AGI_STONE
             *     空:0
             *     石:1
             *     近1:-7
             *
             */
            for (int i = 0; i < this.GetAgiCalcFieldsSize(); i++)
            {
                switch (fields[i])
                {
                    case 0:                         /* 空(F) + 空(S) */
                        break;                      /* 空 */
                    case 1:                         /* 空(F) + 石(S) or 自(F) + 空(S) */
                        fields[i] = MY_FIELD;       /* 自 */
                        break;
                    case 3:                         /* 壁(F) + 空(S) */
                        break;                      /* 壁 */
                    case 5:                         /* 障(F) + 空(S) */
                        break;                      /* 障 */
                    case -11:                       /* 近1(F) + 空(S) */
                        fields[i] = EMPUTY;         /* 空(近再計算の為) */
                        break;
                    case -13:                       /* 近2(F) + 空(S) */
                        fields[i] = EMPUTY;         /* 空(近再計算の為) */
                        break;  

                    case -10:                       /* 近1(F) + 石(S) */
                        fields[i] = MY_FIELD;       /* 自 */
                        break;
                    case -12:                       /* 近2(F) + 石(S) */
                        fields[i] = MY_FIELD;       /* 自 */
                        break;

                    case -7:                        /* 空(F) + 近1(S)*/
                        fields[i] = EMPUTY;         /* 空 */
                        break;
                    case -6:                        /* 自(F) + 近1(S)*/
                        fields[i] = MY_FIELD;       /* 自 */
                        break;
                    case -4:                        /* 壁(F) + 近1(S)*/
                        fields[i] = WALL;           /* 壁 */
                        break;
                    case -2:                        /* 障(F) + 近1(S)*/
                        fields[i] = OBJECT;         /* 障 */
                        break;
                    case -18:                       /* 近1(F) + 近1(S)*/
                        fields[i] = EMPUTY;         /* 空(近再計算の為) */
                        break;
                    case -20:                       /* 近2(F) + 近1(S)*/
                        fields[i] = EMPUTY;         /* 空(近再計算の為) */
                        break;
                    default:
                        break;
                }
            }

            addNeighborInfo();

        }

    }
}
