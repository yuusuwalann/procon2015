﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Procon2015_2
{
    /* アプローチ方法
     * ビンパッキングアルゴリズムを本問題にリダクションする 
     * (1) 石全体を石のサイズで降順ソートし、全体の1/3の値をεとする
     *　サイズε以上で出現順にソートしたリストBigリスト
     * および、ε未満で出現順にソートしたリストSmallリストを用意する 。
     *(2)Bigリストから順に盤面配置を試みる。
     * リスト順に配置し、石のパスも有効とする。
     * 作成された配置情報をキーとし、使用した石の数を含めた情報を格納する。
     * 配置保持で重複した盤面が生じた場合、石の数が少ない盤面を採用する。
     *(3)可能な限り配置が終了した盤面数が一定数を超えた場合、(2)の処理を終了する。
     *(4)Smallリストを使用し、盤面中の空箇所の埋め合わせを試みる。
     *(5)可能な限り配置が終了した盤面で、配置条件(自陣に接触しながら配置できているか)を確認する。
     *(6)条件を満たした盤面のうちで評価値が最も高い盤面を出力する。
     *(6) (1)からパラメータを調整したうえで繰り返す
     *
    */

     /* 各定数情報 
      * AGI_FIELDS 
      *     空：0
      *     自：1
      *     障：5
      *     近1:-11
      *     近2:-13
      *
      * AGI_STONE
      *     空:0
      *     石:1
      *     近1:-7
      *
      */
      
    class Search
    {
        AdvanceGameInfo agi;
        int upperBound;     /* 上界 */
        int lowerBound;     /* 下界 */
        int epsilonSize;
        int outputNo;

        const int EVAL_A = 0;   /* 評価関数(サイズ値あり) */
        const int EVAL_B = 1;   /* 評価関数(サイズ無関係) */
        const int EVAL_C = 2;   /* 評価関数(サイズ関係あり) */

        const int INIT_SEARCH_IDX = 3;  /* 初手最大探索IDX */
        const int INIT_CHOISE_FOR_EVAL_NUM = 50;   /* 初手保持個数 */
        const int INIT_SEEDS_SAVE = 5;             /* 初手種保存数 */

        const int SEARCH_KIND_MAX = 2;              /* 一つに対しx手分調査 */
        const int CHOISE_FOR_EVAL_NUM = 80;        /* 優秀種残し数 */
        const int MY_FIELD = 1;
        const int NEIGHT1 = -11;
        const int NEIGHT2 = -13;

        const int DEPTH_SIZE = 0;

        Dictionary<int, StoreData> storeDataDic;
        Dictionary<string, int> dic;    /* string:FieldsData, int:StoreDataID */
        Queue<int> searchQueId;
        Queue<int> nextQueId;
        Queue<int> answerId;

        enum Kinds  /* Sorce:AGI_StoneKindsList */
        {
            ORIGIN = 0,
            R90, R180, R270, REV_ORG, REV_R90, REV_R180, REV_R270
        }

        public Search()
        {
            agi = null;
            upperBound = 0;
            lowerBound = 0;
            storeDataDic = new Dictionary<int, StoreData>();
            dic = new Dictionary<string, int>();
            searchQueId = new Queue<int>();
            nextQueId = new Queue<int>();
            answerId = new Queue<int>();
            outputNo = 0;
        }

        public Search(AdvanceGameInfo agi)
        {
            this.agi = agi;
            calcUpperLowerBound();  /* init:upperBound, lowerBound */
            storeDataDic = new Dictionary<int, StoreData>();
            dic = new Dictionary<string, int>();
            searchQueId = new Queue<int>();
            nextQueId = new Queue<int>();
            answerId = new Queue<int>();
            outputNo = 0;
        }

        public void SearchStart()
        {
            /* 準備 */
            preparation();

            /* 初手の探索 */
            step1();

            /* 初手の中から探索対象を決める */
            step2();

            /* 2番目以降の探索(BigList) */
            step3();

            /* 2番目以降の探索(SmallList) */
            step4();

            //PrintStoreDataAll();

        }

        private void calcUpperLowerBound() 
        {
            int emptySize = agi.GetAgiFields().GetEmptySize();
            List<int> stoneSizeList = new List<int>();

            /* 全石のサイズを取得 */
            for(int i=0; i < agi.GetAgiStoneList().GetListSize(); i++)
            {
                stoneSizeList.Add(agi.GetAgiStoneList().GetAgiStoneKindsList(i).GetStoneNumSize());
            }

            stoneSizeList.Sort();   /* 昇順ソート */

            int tmpSum = emptySize;
            int counter = 0;
            while(tmpSum >= 0)
            {
                if (counter < stoneSizeList.Count)
                {
                    tmpSum -= stoneSizeList[counter];
                }
                else
                {
                    break;
                }
                counter++;
            }
            upperBound = (counter - 1);

            stoneSizeList.Reverse();    /* 降順ソート */
            tmpSum = emptySize;
            counter = 0;
            while (tmpSum >= 0)
            {
                if (counter < stoneSizeList.Count)
                {
                    tmpSum -= stoneSizeList[counter];
                }
                else
                {
                    break;
                }
                counter++;
            }
            lowerBound = (counter - 1);
        }

        private void preparation()
        {
            createList();
        }

        private void createList()
        {
            Dictionary<int, int> tmpMap = new Dictionary<int, int>();
            /* mapへ登録 (ID, size) */
            for (int i=0; i < agi.GetAgiStoneList().GetListSize(); i++)
            {
                int id = agi.GetAgiStoneList().GetAgiStoneKindsList(i).GetStoneKindsListId();
                int size = agi.GetAgiStoneList().GetAgiStoneKindsList(i).GetStoneNumSize();
                tmpMap.Add(id, size);
            }
            /* mapソート */
            var map = tmpMap.OrderBy((x) => x.Value);
            List<int> sizeOrderList = new List<int>();

            foreach(var data in map)
            {
                sizeOrderList.Add(data.Key);
            }

            /* εを決める */
            int epsId = sizeOrderList[sizeOrderList.Count/3]; //DEBUG
            if(tmpMap.ContainsKey(epsId) == true)
            {
                epsilonSize = tmpMap[epsId];
            }
            else
            {
                epsilonSize = sizeOrderList[0];
            }

            /* 各リストへ登録 (ID, size) */
            for (int i = 0; i < agi.GetAgiStoneList().GetListSize(); i++)
            {
                int id = agi.GetAgiStoneList().GetAgiStoneKindsList(i).GetStoneKindsListId();
                int size = agi.GetAgiStoneList().GetAgiStoneKindsList(i).GetStoneNumSize();
                if( size >= epsilonSize)
                {
                    /* ε以上の場合 */
                }
                else
                {
                    /* ε未満の場合 */
                }
            }

        }

        private void step1()
        {
            /* 初手処理 */
            /* 石1～石(INIT_SEARCH_IDX)まで全探索 */

            AGI_CalcFields calcF = new AGI_CalcFields(agi.GetAgiFields());
            storeRootFields(calcF); /* 親の登録 */

            for (int id = 0; id < INIT_SEARCH_IDX; id++)
            {
                if(id > agi.GetAgiStoneList().GetListSize())    /* 石全体の数よりオーバーした場合 */
                {
                    break;
                }

                for (int idx = 0; idx < calcF.GetAgiCalcFieldsSize(); idx++)    /* すべてのセルで確認 */
                {
                    for (int kind = 0; kind < (int)Kinds.REV_R270; kind++)      /* すべての回転・反転で確認 */
                    {
                        if (agi.GetAgiStoneList().GetAgiStoneKindsList(id).GetAGIStones(kind) == null)    /* 重複により削除された石 */
                        {
                            continue;
                        }
                        AGI_CalcFields resultF = placement(calcF, id, kind, idx, false);   /* 配置確認 */
                        if (resultF == null)  /* 配置失敗 */
                        {
                            continue;
                        }
                        else
                        {
                            /* ROOT_ID = 0 */
                            if(storeFields(resultF, 0, id, kind, idx, calcF, EVAL_B) == -1)  /* 書き込み失敗 */
                            {
                                continue;
                            }
                        }
                    }
                }

            }

        }

        private void step2()
        {
            Dictionary<int, float> tmpMap = new Dictionary<int, float>();

            /* map作成(ID, evalue) */
            for (int i = 1; i < storeDataDic.Count; i++)
            {
                tmpMap.Add(storeDataDic[i].ID, storeDataDic[i].evalue);
            }

            /* mapソート */
            var map = tmpMap.OrderByDescending((x) => x.Value); /* 降順ソート */
            int[] saveSeeds = new int[INIT_SEARCH_IDX];
            for (int i = 0; i < INIT_SEARCH_IDX; i++)
            {
                saveSeeds[i] = 0;
            }


            /* 評価値が優秀な種/評価値が優秀であり石ファイルが異なる種 */
            int count = 0;
            /* INIT_CHOISE_FOR_EVAL_NUM分Queueに格納 */
            foreach (var data in map)
            {
                int id = data.Key;
                if (count < INIT_CHOISE_FOR_EVAL_NUM)
                {
                    if (searchQueId.Contains(id) != true)
                    {
                        searchQueId.Enqueue(id);
                        count++;
                    }
                    else
                    {
                        continue;
                    }
                }
                else
                {
                    /* INIT_CHOISE_FOR_EVAL_NUM分Queueに格納 */
                    if (saveSeeds[storeDataDic[id].GetFinallyStoneId()] < INIT_SEEDS_SAVE)
                    {
                        if (searchQueId.Contains(id) != true)
                        {
                            searchQueId.Enqueue(id);
                            saveSeeds[storeDataDic[id].GetFinallyStoneId()]++;
                        }
                        else
                        {
                            continue;
                        }
                    }
                    else
                    {
                        /* メモリ節約_不要情報削除 */
                        storeDataDic.Remove(id);
                        var key = dic.FirstOrDefault(x => x.Value.Equals(id)).Key;          /* dicのValue(ID)よりFields(Key)を取得 */
                        if (key != null)
                        {
                            dic.Remove(key);
                        }
                    }

                }
            }
        }

        private void step3()
        {
            /* 2手以降処理 */
            /* 当てはめ先は自陣の近似1 or 近似2セル */
            for (;;)
            {
                if(searchQueId.Count == 0)
                {
                    break;
                }
                for (int i = 0; i < DEPTH_SIZE; i++)
                {
                    queueDepthSearch();
                }
                queueSearch();
                selectionQueue();
                if (searchQueId.Count != 0)
                {
                    Console.WriteLine("id={0},eval={1}, score={2}", searchQueId.Peek(), storeDataDic[searchQueId.Peek()].evalue, storeDataDic[searchQueId.Peek()].score);
                    var key = dic.FirstOrDefault(x => x.Value.Equals(searchQueId.Peek())).Key;          /* dicのValue(ID)よりFields(Key)を取得 */
                    if (key != null)
                    {
                        AGI_CalcFields debug = new AGI_CalcFields(key);
                        debug.PrintAgiCalcFields();
                    }
                }
            }
        }

        private void step4()
        {
            int outputId = getOutputId();

            Output op = new Output(agi);
            StoreData st = storeDataDic[outputId];
            st.PrintStoreData();
            for(int i=0; i < st.GetStoneInfoSize(); i++)
            {
                op.SetStone(st.GetStoneInfoId(i), st.GetStoneInfoKind(i), st.GetStoneInfoPlace(i));
            }
            var key = dic.FirstOrDefault(x => x.Value.Equals(outputId)).Key;
            if (key != null)
            {
                AGI_CalcFields debug = new AGI_CalcFields(key);
                debug.PrintAgiCalcFields();
            }
            op.OutputExec(outputNo);
            outputNo++;
        }

        /* StoreDataへ格納 */
        private int storeFields(AGI_CalcFields agicF, int parentId, int stoneId, int kinds, int placeIdx, AGI_CalcFields beforeAgiF, int evalKind)
        {
            int retId = -1;

            /* Field情報をString化 */
            string key = exchangeFieldsToString(agicF) ;

            /* ディクショナリ登録有無チェック */
            int unregistTimes = storeDataDic[parentId].placeTime + 1;
            if (dic.ContainsKey(key) == true)
            {
                /* 存在した場合 */
                int targetId = dic[key];
                StoreData sd = storeDataDic[targetId];
                if (unregistTimes > sd.placeTime)
                {
                    /* 新規登録予定が既存の作成回数より大きい場合 */
                    return -1; /* 作成中断 */
                }
                else
                {
                    ;   /* 登録実施 */
                }

            }
            else
            {
                /* 未登録の場合 */
                ;   /* 登録実施 */
            }

            /* 各種登録 */
            /* ID取得 */
            StoreData regist = new StoreData(true);
            /* ディクショナリ登録 */
            dic[key] = regist.ID;
            /* store登録 */
            regist.placeTime = unregistTimes;
            /* stoneの登録(親のstoneを受け継ぐ) */
            for(int i=0; i < storeDataDic[parentId].GetStoneInfoSize(); i++)
            {
                regist.SetStoneInfo(storeDataDic[parentId].GetStoneInfoId(i), 
                    storeDataDic[parentId].GetStoneInfoPlace(i), storeDataDic[parentId].GetStoneInfoKind(i));
            }
            regist.SetStoneInfo(stoneId, placeIdx, kinds);
            regist.score = calcScore(agicF);
            if (evalKind == EVAL_A)
            {  /* サイズが大きいほど有利 */
                regist.evalue = calcEvalSize(agicF, beforeAgiF);
            }
            else if(evalKind == EVAL_B)
            {
                regist.evalue = calcEval(agicF, beforeAgiF);
            }
            else
            {
                regist.evalue = calcEvalSizeKai(agicF, beforeAgiF, regist.score);
            }

            storeDataDic.Add(regist.ID, regist);
            retId = regist.ID;
            return retId;
        }

        /* 問題文をディクショナリに格納 */
        private bool storeRootFields(AGI_CalcFields agicF)
        {
            bool result = true;

            /* Field情報をString化 */
            string key = "";
            for (int i = 0; i < agicF.GetAgiCalcFieldsSize(); i++)
            {
                key += agicF.GetAgiCalcFieldNum(i).ToString();
            }

            /* 各種登録 */
            /* ID取得 */
            StoreData regist = new StoreData(false);
            regist.ID = 0;  /* ROOTのID */
            /* ディクショナリ登録 */
            dic[key] = regist.ID;
            /* store登録 */
            regist.placeTime = 0;
            regist.evalue = 0.0F;
            regist.score = calcScore(agicF);
            storeDataDic.Add(regist.ID, regist);

            return result;
        }

        /* サイズを含めた評価関数(EVAL_A) */
        private float calcEvalSize(AGI_CalcFields agicF, AGI_CalcFields beforeAgicF)
        {
            float eval = 0;

            eval = agicF.GetAgiCalcEvalSize(beforeAgicF);

            return eval;

        }

        /* サイズに影響しない評価関数(EVAL_B) */
        private float calcEval(AGI_CalcFields agicF, AGI_CalcFields beforeAgicF)
        {
            float eval = 0;

            eval = agicF.GetAgiCalcEval(beforeAgicF);

            return eval;

        }

        /* サイズを含めた評価関数評価関数(EVAL_C) */
        private float calcEvalSizeKai(AGI_CalcFields agicF, AGI_CalcFields beforeAgicF,int score)
        {
            float eval = 0;

            eval = agicF.GetAgiCalcEvalSizeKai(beforeAgicF,score);

            return eval;

        }
        
        /* スコアの計算 */
        private int calcScore(AGI_CalcFields agicF)
        {
            int score = 0;

            score = agicF.GetAgiCalcScore();

            return score;
        }

        /* 石の配置 NG:null */
        private AGI_CalcFields placement(AGI_CalcFields agicOrgF, int stoneId, int kinds, int placeIdx, bool connectCheck)
        {
            AGI_CalcFields retAgicF = new AGI_CalcFields();

            retAgicF.SetAgiCalcCopyFromA(agicOrgF); /* 全体をコピー */
            AGI_Stones setStone = new AGI_Stones(agi.GetAgiStoneList().GetAgiStoneKindsList(stoneId).GetAGIStones(kinds));
            /* 石の加算処理 */
            for(int i=0;  i< setStone.GetSize(); i++)
            {
                int idx = agiST2agiF(retAgicF.GetMaxX(), retAgicF.GetMaxY(), setStone.GetXSize(), setStone.GetYSize(), placeIdx, i);
                retAgicF.SetAgiCalcNum
                    (idx,   /* 得られた変換座標 */
                    retAgicF.GetAgiCalcFieldNum(idx) + setStone.GetNum(i)); /* 元の値 + 石の値 */
            }
            /* 判定 */
            bool connectFlg = false;    /* 自陣と接続するか判定 */
            for(int i=0; i < retAgicF.GetAgiCalcFieldsSize(); i++)
            {
                int tmp = retAgicF.GetAgiCalcFieldNum(i);
                if( (tmp > 0) && (tmp%2 == 0))
                {
                    /* 正の偶数値があった場合、自・壁・障のいずれかと重なる */
                    return null;
                }
                if((connectFlg == false) && (tmp == -6)) /* 近傍(-7) + 自陣(1) */
                {
                    connectFlg = true;
                }
            }
            if((connectCheck == true) && (connectFlg != true))
            {
                return null;
            }

            /* 加算前(石設置済み)に戻す */
            retAgicF.GetReturnCalcFld();
            
            return retAgicF;
        }

        /* 座標変換 AGI_Stone ⇒ AGI_Fields */
        private int agiST2agiF(int fMaxX, int fMaxY, int sMaxX, int sMaxY, int agiAgLUIdx, int agiStIdx)
        {
            int retFIdx = 0;

            int agLUX = agiAgLUIdx % fMaxX; /* 頂点(F)からX座標(F)を得る */
            int agLUY = agiAgLUIdx / fMaxX; /* 頂点(F)からY座標(F)を得る */

            int stX = agiStIdx % sMaxX;     /* 変換IDX(S)からX座標(S)を得る */
            int stY = agiStIdx / sMaxX;     /* 変換IDX(S)からY座標(S)を得る */

            int ag_stX = stX + agLUX;       /* 頂点(F)+X座標(S)から変換X座標(F)を得る */
            int ag_stY = stY + agLUY;       /* 頂点(F)+Y座標(S)から変換Y座標(F)を得る */

            retFIdx = ag_stY * fMaxX + ag_stX;  /* X座標(F)とY座標(F)からIDX(F)を得る */

            return retFIdx;
        }

        public void PrintStoreDataAll()
        {
            Console.WriteLine("");
            Console.WriteLine("ID,配置回数,親ID,石ID,接地Index,向き,評価値,スコア");
            for(int i=0; i < storeDataDic.Count; i++)
            {
                Console.WriteLine("{0},{1},{2},{3}", 
                    storeDataDic[i].ID.ToString(), 
                    storeDataDic[i].placeTime.ToString(), 
                    storeDataDic[i].evalue.ToString(), 
                    storeDataDic[i].score.ToString());
            }
        }

        private string exchangeFieldsToString(AGI_CalcFields agicF)
        {
            string strRet = "";

            for (int i = 0; i < agicF.GetAgiCalcFieldsSize(); i++)
            {
                strRet += agicF.GetAgiCalcFieldNum(i).ToString();
            }

            return strRet;
        }

        private void queueSearch()
        {
            while ((searchQueId.Count) > 0)  /* Queueがなくなるまで無限ループ */
            {
                /// Console.WriteLine(searchQueId.Count);
                int targetId = searchQueId.Dequeue();                       /* キューからID取得 */
                var key = dic.FirstOrDefault(x => x.Value.Equals(targetId)).Key;          /* dicのValue(ID)よりFields(Key)を取得 */
                if(key == null)
                {
                    continue;
                }
                string strFields = key.ToString();                          /* キーをStirngへ変換 */
                AGI_CalcFields tgtAgiCF = new AGI_CalcFields(strFields);    /* stringからAGI_CalcFieldsを復元 */
                StoreData tgtSD = storeDataDic[targetId];

                for (int idKind = (tgtSD.GetFinallyStoneId()+1); idKind <= tgtSD.GetFinallyStoneId() + SEARCH_KIND_MAX; idKind++)  /* SEARCH_KIND_MAX先分走査 */
                {
                    /* 石の決定 */
                    if (idKind >=  agi.GetAgiStoneList().GetListSize()) /* 石最大オーバー */
                    {
                        answerId.Enqueue(targetId);
                        break;
                    }

                    for (int idx = 0; idx < tgtAgiCF.GetAgiCalcFieldsSize(); idx++)      /* 接地セル走査 */
                    {
                        if ((tgtAgiCF.GetAgiCalcFieldNum(idx) == MY_FIELD) || (tgtAgiCF.GetAgiCalcFieldNum(idx) == NEIGHT1) || (tgtAgiCF.GetAgiCalcFieldNum(idx) == NEIGHT2))
                        { /* 自陣,近似1の場合 */
                            for (int kind = 0; kind < (int)Kinds.REV_R270; kind++)
                            {
                                if (agi.GetAgiStoneList().GetAgiStoneKindsList(idKind).GetAGIStones(kind) == null)    /* 重複により削除された石 */
                                {
                                    continue;
                                }
                                /* 石用のIDXからフィールド用に変更 */
                                /* AGI_Stonesの近傍セルを不要とするように対応 */
                                /*
                                int idx2 = stoneIdxToPlacementIdx(idx);
                                if(idx2 == -1)
                                {
                                    continue;
                                }
                                */

                                AGI_CalcFields resultF = placement(tgtAgiCF, idKind, kind, idx, true);   /* 配置確認 */
                                if (resultF == null)  /* 配置失敗 */
                                {
                                    continue;
                                }
                                else
                                {
                                    int retId = storeFields(resultF, tgtSD.ID, idKind, kind, idx, tgtAgiCF, EVAL_C);
                                    if (retId == -1)  /* 書き込み失敗 */
                                    {
                                        continue;
                                    }
                                    else
                                    {
                                        nextQueId.Enqueue(retId);
                                    }
                                }

                            }

                        }
                    }
                }
            }

        }

        private void queueDepthSearch()
        {
            int queDefaultCount = searchQueId.Count;
            int searchCnt = 1;

            while ((searchCnt) < queDefaultCount)  /* 初回キューされていた分実施 */
            {
                searchCnt++;
                /// Console.WriteLine(searchQueId.Count);
                int targetId = searchQueId.Dequeue();                       /* キューからID取得 */
                var key = dic.FirstOrDefault(x => x.Value.Equals(targetId)).Key;          /* dicのValue(ID)よりFields(Key)を取得 */
                if (key == null)
                {
                    continue;
                }
                string strFields = key.ToString();                          /* キーをStirngへ変換 */
                AGI_CalcFields tgtAgiCF = new AGI_CalcFields(strFields);    /* stringからAGI_CalcFieldsを復元 */
                StoreData tgtSD = storeDataDic[targetId];

                for (int idKind = (tgtSD.GetFinallyStoneId() + 1); idKind <= tgtSD.GetFinallyStoneId() + SEARCH_KIND_MAX; idKind++)  /* SEARCH_KIND_MAX先分走査 */
                {
                    /* 石の決定 */
                    if (idKind >= agi.GetAgiStoneList().GetListSize()) /* 石最大オーバー */
                    {
                        break;
                    }

                    for (int idx = 0; idx < tgtAgiCF.GetAgiCalcFieldsSize(); idx++)      /* 接地セル走査 */
                    {
                        if ((tgtAgiCF.GetAgiCalcFieldNum(idx) == MY_FIELD) || (tgtAgiCF.GetAgiCalcFieldNum(idx) == NEIGHT1) || (tgtAgiCF.GetAgiCalcFieldNum(idx) == NEIGHT2))
                        { /* 自陣,近似1の場合 */
                            for (int kind = 0; kind < (int)Kinds.REV_R270; kind++)
                            {
                                if (agi.GetAgiStoneList().GetAgiStoneKindsList(idKind).GetAGIStones(kind) == null)    /* 重複により削除された石 */
                                {
                                    continue;
                                }
                                /* 石用のIDXからフィールド用に変更 */
                                /* AGI_Stonesの近傍セルを不要とするように対応 */
                                int idx2 = stoneIdxToPlacementIdx(idx);
                                if (idx2 == -1)
                                {
                                    continue;
                                }

                                AGI_CalcFields resultF = placement(tgtAgiCF, idKind, kind, idx2, true);   /* 配置確認 */
                                if (resultF == null)  /* 配置失敗 */
                                {
                                    continue;
                                }
                                else
                                {
                                    int retId = storeFields(resultF, tgtSD.ID, idKind, kind, idx, tgtAgiCF, EVAL_C);
                                    if (retId == -1)  /* 書き込み失敗 */
                                    {
                                        continue;
                                    }
                                    else
                                    {
                                        searchQueId.Enqueue(retId); /* 再実施のため、searchQueIDに格納 */
                                    }
                                }

                            }

                        }
                    }
                }
            }

        }

        private void selectionQueue()
        {
            Dictionary<int, float> tmpMap = new Dictionary<int, float>();

            /* マップ作成 */
            int countId = nextQueId.Count;
            for (int i=0; i < countId; i++)
            {
                int id = nextQueId.Dequeue();
                float eval = storeDataDic[id].evalue;
                tmpMap.Add(id, eval);
            }

            /* ソート */
            /* mapソート */
            var map = tmpMap.OrderByDescending((x) => x.Value); /* 降順ソート */

            /* 評価値が優秀な種 */
            int count = 0;
            /* CHOISE_FOR_EVAL_NUM分Queueに格納 */
            foreach (var data in map)
            {
                int id = data.Key;
                if (searchQueId.Contains(id) != true)
                {
                    if (count < CHOISE_FOR_EVAL_NUM)
                    {
                        searchQueId.Enqueue(id);
                        count++;
                    }
                    else
                    {
                        /* メモリ節約_不要情報削除 */
                        storeDataDic.Remove(id);
                        var key = dic.FirstOrDefault(x => x.Value.Equals(id)).Key;          /* dicのValue(ID)よりFields(Key)を取得 */
                        if (key != null)
                        {
                            dic.Remove(key);
                        }
                    }
                }
            }
        }

        /* 配置用の原点は近傍セルを含んでいるため、含まない形に変更する */
        private int stoneIdxToPlacementIdx(int idx)
        {
            int ret = 0;

            ret = idx - agi.GetAgiFields().GetMaxX() - 1;

            if(ret >= 0)
            {
                return ret;
            }

            return -1;
        }

        private int getOutputId()
        {
            /* スコアの一番高い結果を出力 */
            Dictionary<int, int> tmpMap = new Dictionary<int, int>();

            /* マップ作成 */
            int countId = answerId.Count;
            for (int i = 0; i < countId; i++)
            {
                int id = answerId.Dequeue();
                int score = storeDataDic[id].score;
                tmpMap.Add(id, score);
            }

            /* ソート */
            /* mapソート */
            var map = tmpMap.OrderByDescending((x) => x.Value); /* 降順ソート */
            int outputId = -1 ;
            /* 一番Scoreの高い結果を出力　*/
            foreach (var data in map)
            {
                outputId = data.Key;
                break;
            }

            return outputId;
        }
    }
}
