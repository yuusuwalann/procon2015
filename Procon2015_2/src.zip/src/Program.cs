﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Procon2015_2
{
    class Program
    {
        static void Main(string[] args)
        {
            GameInfo gi = new GameInfo();
            gi.GetProblem("q.txt");
            AdvanceGameInfo agi = new AdvanceGameInfo(gi);
            Search sch = new Search(agi);
            sch.SearchStart();

        }
    }
}
